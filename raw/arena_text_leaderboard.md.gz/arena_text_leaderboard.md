Title: Text Arena: LLM Rankings & AI Model Benchmarks

URL Source: https://arena.ai/leaderboard/chat/text

Markdown Content:
New Chat
Leaderboard
Search
Get More Done With Agents

Start evaluating agentic AI on Arena today. Learn more

Try it now
Hide this
Log In
Terms of Use
Privacy Policy
Cookies
Overview
Agent
Chat
Code
Image
Video
Start Voting
View as
Ranking
Pareto
Categories(29)
🏆
Overall
🤓
Expert
Learn more
💼
Occupational
🧮
Math
📝
Instruction Following
💬
Multi-Turn
✍️
Creative Writing
💻
Coding
🌶️
Hard Prompts
🧠
Hard Prompts (English)
+ View more
Adjustments
Style Control
Factuality
Learn more
None
License Type
All
Proprietary
Open Source
Score Range
Min
953
Max
1524
Input Price
Min
$0.00
Max
$75
Output Price
Min
$0.00
Max
$150
Context Length
Min
2K
Max
2.1M
Text Arena
🏆
Overall
View overall rankings across various AI models in text-to-text tasks across math, coding, creative writing, and other open-ended domains.
Oct 20, 2026
8,900,458 votes
417 models
Hide Filters
Models
Labs
Rank
	
Rank Spread
	
Model
	
Score
	
Votes
	
Price $/M
	
Context


1
	
1
3
	
Gemini 4 Argon (High)
Google · Proprietary
	
1524
±9
Preliminary
	4,900	$2 / $10	1M

2
	
1
8
	
Muse Wonder (Max)
Meta · Proprietary
	
1510
±9
	5,099	$4 / $20	1M

3
	
1
7
	
Claude Opus 5.5 (High)
Anthropic · Proprietary
	
1509
±7
	9,496	$4 / $20	1M

4
	
2
10
	
Claude Fable 5 (High)
Anthropic · Proprietary
	
1504
±4
	43,399	$10 / $50	1M

5
	
2
10
	
Claude Opus 4.6 (High)
Anthropic · Proprietary
	
1503
±3
	82,619	$5 / $25	1M

6
	
2
12
	
Claude Fable 5.1 (Max)
Anthropic · Proprietary
	
1503
±6
	15,623	$10 / $50	1M

7
	
2
12
	
Claude Opus 4.7 (High)
Anthropic · Proprietary
	
1501
±4
	65,131	$5 / $25	1M

8
	
4
17
	
Claude Opus 4.6
Anthropic · Proprietary
	
1497
±3
	87,372	$5 / $25	1M

9
	
3
18
	
Gemini 3.8 Flash (High)
Google · Proprietary
	
1496
±5
Preliminary
	41,423	$0.75 / $3.75	1M

10
	
4
19
	
Muse Spark 1.3 (Max)
Meta · Proprietary
	
1495
±5
	19,323	$1.25 / $4.25	1M

11
	
6
18
	
Claude Opus 4.7
Anthropic · Proprietary
	
1494
±4
	66,185	$5 / $25	1M

12
	
6
26
	
Muse Spark 1.2 (xHigh)
Meta · Proprietary
	
1492
±7
	9,578	$1.25 / $4.25	N/A

13
	
8
25
	
Claude Opus 5 (Max)
Anthropic · Proprietary
	
1491
±5
	33,683	$5 / $25	1M

14
	
8
25
	
Muse Spark 1.1
Meta · Proprietary
	
1490
±4
	44,815	$1.25 / $4.25	N/A

15
	
8
25
	
Claude Opus 5 (High)
Anthropic · Proprietary
	
1490
±4
	69,307	$5 / $25	1M

16
	
8
30
	
Muse Spark
Meta · Proprietary
	
1489
±6
	14,153	N/A	N/A

17
	
8
29
	
Gemini 3.7 Flash (High)
Google · Proprietary
	
1489
±5
Preliminary
	29,177	$0.75 / $3.75	1M

18
	
9
30
	
Kimi K3 (Max)
Moonshot · Kimi K3 license
	
1488
±5
	34,325	N/A	N/A

19
	
11
29
	
Gemini 3.1 Pro Preview
Google · Proprietary
	
1487
±3
	129,523	$1 / $6	1M

20
	
12
30
	
Gemini 3 Pro
Google · Proprietary
	
1485
±4
	42,059	$2 / $12	1M

21
	
12
34
	
GPT-5.6 Sol (xHigh)
OpenAI · Proprietary
	
1484
±4
	41,803	$4 / $20	N/A

22
	
12
40
	
Gemini 3.6 Flash (High)
Google · Proprietary
	
1483
±4
	36,079	$0.75 / $3.75	1M

23
	
12
42
	
Qwen3.8-Max
Alibaba · Proprietary
	
1483
±5
	29,418	$2 / $6	1M

24
	
16
42
	
GPT-5.5 (High)
OpenAI · Proprietary
	
1481
±4
	69,340	$5 / $30	1.1M

25
	
16
43
	
Claude Opus 4.8 (High)
Anthropic · Proprietary
	
1481
±4
	64,063	$5 / $25	1M

26
	
15
44
	
GLM-5.3 (Max)
Z.ai · MIT
	
1481
±5
	24,035	$1.40 / $4.40	1M

27
	
12
51
	
MiMo-V2.6-Pro
Xiaomi · MIT
	
1480
±9
	4,065	$0.43 / $0.87	1.1M

28
	
12
48
	
GPT-6.1 Sol (Max)
OpenAI · Proprietary
	
1479
±8
	7,453	$2 / $10	1.1M

29
	
21
47
	
Gemini 3.5 Flash (High)
Google · Proprietary
	
1477
±4
	48,479	$0.75 / $4.50	1M

30
	
16
52
	
Claude Sonnet 5.5 (xHigh)
Anthropic · Proprietary
	
1477
±7
	8,126	$2 / $10	1M

31
	
21
47
	
GPT-5.5
OpenAI · Proprietary
	
1477
±4
	70,970	$5 / $30	1.1M

32
	
22
48
	
GLM-5.2 (Max)
Z.ai · MIT
	
1476
±4
	51,221	$1.40 / $4.40	1M

33
	
22
48
	
Gemini 3.5 Flash (Medium)
Google · Proprietary
	
1476
±4
	47,228	$0.75 / $4.50	1M

34
	
21
54
	
GPT-6 Astra (Max)
OpenAI · Proprietary
	
1476
±6
	13,293	N/A	N/A

35
	
22
49
	
GPT-5.2 Chat (20260210)
OpenAI · Proprietary
	
1475
±4
	35,991	$1.75 / $14	128K

36
	
21
54
	
DeepSeek-V4.1-Flash-20260910 (Max)
DeepSeek · MIT
	
1475
±6
	13,444	$0.30 / $1.20	1M

37
	
22
49
	
GPT-5.4 (High)
OpenAI · Proprietary
	
1475
±4
	64,755	$2.50 / $15	1.1M

38
	
22
51
	
GLM-5.3-Flash
Z.ai · MIT
	
1475
±5
	36,095	$0.05 / $0.18	1M

39
	
22
51
	
Grok 4.20 Beta 1
SpaceXAI · Proprietary
	
1475
±5
	27,918	N/A	N/A

40
	
23
51
	
Claude Opus 4.8
Anthropic · Proprietary
	
1474
±4
	65,151	$5 / $25	1M

41
	
18
61
	
Qwen3.7-Max-Preview
Alibaba · Proprietary
	
1474
±10
	3,942	$1.48 / $4.42	1M

42
	
25
52
	
Claude Opus 4.5 (High, 32K, 20251101)
Anthropic · Proprietary
	
1474
±4
	37,500	$5 / $25	200K

43
	
23
58
	
GPT-5.5 Instant
OpenAI · Proprietary
	
1473
±5
	27,154	$5 / $30	1.1M

44
	
26
55
	
Gemini 3 Flash
Google · Proprietary
	
1473
±4
	31,311	$0.50 / $3	1M

45
	
27
55
	
Claude Sonnet 4.6
Anthropic · Proprietary
	
1472
±4
	70,931	$1.50 / $7.50	1M

46
	
27
58
	
Grok 4.20 Beta (Reasoning, 0309)
SpaceXAI · Proprietary
	
1472
±4
	66,403	$1.25 / $2.50	1M

47
	
27
58
	
Grok 4.20 Multi-Agent Beta (0309)
SpaceXAI · Proprietary
	
1471
±4
	64,920	$1.25 / $2.50	1M

48
	
29
58
	
Claude Opus 4.5 (20251101)
Anthropic · Proprietary
	
1470
±3
	72,863	$5 / $25	200K

49
	
34
61
	
GPT-5.6 Terra (xHigh)
OpenAI · Proprietary
	
1467
±4
	45,201	$2 / $12	N/A

50
	
32
61
	
ERNIE 5.1
Baidu · Proprietary
	
1467
±5
	39,447	$0.56 / $2.54	119K

51
	
38
61
	
MiMo-V2.5-Pro
Xiaomi · MIT
	
1466
±4
	77,367	$0.30 / $0.61	1.1M

52
	
40
65
	
Grok 4.5
SpaceXAI · Proprietary
	
1465
±4
	39,844	$2 / $6	500K

53
	
42
63
	
GLM-5.1
Z.ai · MIT
	
1465
±4
	64,352	$1.40 / $4.40	202.8K

54
	
44
62
	
Grok 4.1 (Thinking)
SpaceXAI · Proprietary
	
1465
±3
	66,478	N/A	N/A

55
	
44
65
	
GPT-5.4
OpenAI · Proprietary
	
1465
±4
	67,829	$2.50 / $15	1.1M

56
	
40
67
	
Qwen3.5-Max-Preview
Alibaba · Proprietary
	
1465
±5
	22,608	$1.20 / $6	N/A

57
	
34
74
	
DeepSeek-V4-Pro (High, 20260813)
DeepSeek · MIT
	
1465
±7
	9,805	$1.32 / $3.96	N/A

58
	
48
75
	
Claude Sonnet 5 (High)
Anthropic · Proprietary
	
1461
±4
	50,871	$2 / $10	1M

59
	
48
76
	
Kimi K2.6
Moonshot · Modified MIT
	
1461
±4
	40,014	$0.95 / $4	262.1K

60
	
44
83
	
Qwen3.6-Max-Preview
Alibaba · Proprietary
	
1460
±8
	5,427	$1.27 / $7.61	262.1K

61
	
52
76
	
Grok 4.1
SpaceXAI · Proprietary
	
1459
±3
	68,635	N/A	N/A

62
	
48
82
	
GPT-6 Sol (Max)
OpenAI · Proprietary
	
1459
±6
	13,790	$2 / $10	1.1M

63
	
54
76
	
Gemini 3 Flash (Minimal)
Google · Proprietary
	
1458
±3
	91,005	$0.50 / $3	1M

64
	
53
79
	
DeepSeek-V4-Pro
DeepSeek · MIT
	
1458
±4
	57,564	$1.32 / $3.96	1M

65
	
54
82
	
GLM-5
Z.ai · MIT
	
1457
±4
	29,268	$1 / $3.20	204.8K

66
	
57
79
	
Claude Sonnet 4.5 (High, 32K, 20250929)
Anthropic · Proprietary
	
1456
±3
	83,921	$3 / $15	200K

67
	
57
82
	
Dola Seed 2.0 Pro
Bytedance · Proprietary
	
1456
±3
	79,109	N/A	N/A

68
	
57
83
	
GPT-5.1 (High)
OpenAI · Proprietary
	
1456
±4
	41,651	$0.63 / $5	400K

69
	
56
83
	
Qwen3.7-Plus
Alibaba · Proprietary
	
1456
±4
	42,030	$0.32 / $1.28	1M

70
	
56
85
	
Grok 4.6 (High)
SpaceXAI · Proprietary
	
1455
±5
	30,919	$2 / $6	500K

71
	
57
85
	
Gemini 3.5 Flash-Lite
Google · Proprietary
	
1455
±4
	35,820	$0.15 / $1.25	1M

72
	
58
83
	
Claude Sonnet 4.5 (20250929)
Anthropic · Proprietary
	
1455
±3
	82,669	$3 / $15	1M

73
	
57
83
	
DeepSeek-V4-Pro Preview (High)
DeepSeek · MIT
	
1455
±4
	54,879	$1.32 / $3.96	1M

74
	
57
90
	
Hy3
Tencent · Apache 2.0
	
1453
±6
	12,791	$0.13 / $0.53	262.1K

75
	
59
88
	
GPT-5.6 Luna (xHigh)
OpenAI · Proprietary
	
1452
±4
	41,052	$0.20 / $1.20	N/A

76
	
57
97
	
Gemma 4 31B
Google · Apache 2.0
	
1452
±7
	6,134	$0.99 / $1.49	131.1K

77
	
62
91
	
GPT-5.3 Chat
OpenAI · Proprietary
	
1450
±4
	34,343	$1.75 / $14	111.6K

78
	
64
91
	
Kimi K2.5 (Thinking)
Moonshot · Modified MIT
	
1450
±3
	74,712	$0.60 / $3	N/A

79
	
64
91
	
Claude Opus 4.1 (Thinking 16K, 20250805)
Anthropic · Proprietary
	
1450
±3
	49,545	$15 / $75	200K

80
	
62
100
	
MiMo-V2.6-Flash
Xiaomi · MIT
	
1449
±6
	12,629	$0.14 / $0.28	1M

81
	
62
100
	
ERNIE-5.0-Preview (1203)
Baidu · Proprietary
	
1449
±7
	9,802	N/A	N/A

82
	
72
96
	
Claude Opus 4.1 (20250805)
Anthropic · Proprietary
	
1448
±3
	77,226	$7.50 / $37.50	200K

83
	
67
99
	
MiMo-V2-Pro
Xiaomi · Proprietary
	
1448
±5
	25,439	$1.10 / $3.30	1M

84
	
72
99
	
GPT-5.4 mini (High)
OpenAI · Proprietary
	
1447
±4
	63,442	$0.75 / $4.50	400K

85
	
64
107
	
Step 5 Preview
StepFun · Proprietary
	
1446
±7
	8,756	$1 / $2.70	1M

86
	
74
100
	
ERNIE 5.0 (0110)
Baidu · Proprietary
	
1446
±4
	36,475	N/A	N/A

87
	
75
99
	
Gemini 2.5 Pro
Google · Proprietary
	
1445
±2
	125,320	$1.25 / $10	1M

88
	
74
108
	
GPT-4.5 Preview (2025-02-27)
OpenAI · Proprietary
	
1445
±6
	14,547	$75 / $150	128K

89
	
76
108
	
Qwen3.6-Plus
Alibaba · Proprietary
	
1443
±4
	48,129	$0.50 / $3	1M

90
	
79
106
	
ChatGPT-4o Latest (20250326)
OpenAI · Proprietary
	
1443
±3
	81,904	$5 / $15	128K

91
	
74
113
	
Grok 4.7 (xHigh)
SpaceXAI · Proprietary
	
1442
±6
	13,489	$2 / $6	500K

92
	
79
111
	
Grok 4.3
SpaceXAI · Proprietary
	
1442
±4
	71,347	$1.25 / $2.50	1M

93
	
79
111
	
Inkling
Thinky · Apache 2.0
	
1441
±4
	42,506	$1 / $4.05	524.3K

94
	
81
110
	
Qwen3.5-397B-A17B
Alibaba · Apache 2.0
	
1441
±3
	95,123	$0.50 / $3.60	262.1K

95
	
75
116
	
GLM-4.7
Z.ai · MIT
	
1441
±6
	12,245	$0.54 / $1.98	204.8K

96
	
79
112
	
GPT-6 Luna (Max)
OpenAI · Proprietary
	
1441
±4
	63,594	$0.10 / $0.50	1.1M

97
	
81
112
	
MiniMax-M3
MiniMax · MiniMax Community License
	
1441
±4
	65,792	$0.30 / $1.20	524.3K

98
	
84
117
	
DeepSeek-V4-Flash Preview (High)
DeepSeek · MIT
	
1439
±4
	51,762	$0.30 / $1.20	1M

99
	
87
116
	
GPT-5.1
OpenAI · Proprietary
	
1439
±4
	44,412	$0.63 / $5	400K

100
	
80
124
	
Gemma 4 26B A4B
Google · Apache 2.0
	
1437
±7
	6,090	N/A	N/A

101
	
87
117
	
GPT-5.2 (High)
OpenAI · Proprietary
	
1437
±4
	49,646	$0.88 / $7	400K

102
	
87
121
	
Qwen3.8-27B
Alibaba · Apache 2.0
	
1437
±5
	25,103	$0.40 / $3	262.1K

103
	
87
121
	
LongCat-Flash-Chat Exp (2602)
Meituan · Proprietary
	
1436
±5
	29,268	N/A	N/A

104
	
79
130
	
Beam 1.0 501B A23B
Reflection · Apache 2.0
	
1436
±9
	4,200	$0.30 / $1	1M

105
	
87
121
	
DeepSeek-V4-Flash
DeepSeek · MIT
	
1436
±4
	51,959	$0.30 / $1.20	1M

106
	
91
121
	
GPT-5.2
OpenAI · Proprietary
	
1435
±3
	83,835	$0.88 / $7	400K

107
	
89
124
	
GPT-5 (High)
OpenAI · Proprietary
	
1435
±5
	31,717	$0.63 / $5	400K

108
	
91
125
	
Qwen3-Max-Preview
Alibaba · Proprietary
	
1434
±5
	27,375	$0.78 / $3.90	262.1K

109
	
92
125
	
MiMo-V2.5
Xiaomi · MIT
	
1434
±4
	47,330	$0.12 / $0.24	1.1M

110
	
87
129
	
GLM-5V-Turbo
Z.ai · Proprietary
	
1433
±6
	10,477	$1.20 / $4	202.8K

111
	
96
125
	
Gemini 3.1 Flash-Lite Preview
Google · Proprietary
	
1433
±4
	64,188	$0.25 / $1.50	1M

112
	
88
131
	
Mistral Large 4
Mistral · Proprietary
	
1433
±7
	9,308	$0.68 / $2.09	1M

113
	
97
127
	
o3 (2025-04-16)
OpenAI · Proprietary
	
1432
±4
	58,903	$2 / $8	200K

114
	
97
133
	
MiMo-V2-Omni
Xiaomi · Proprietary
	
1431
±6
	20,609	$0.44 / $2.20	256K

115
	
94
136
	
Kimi K2.5 (Instant)
Moonshot · Modified MIT
	
1431
±7
	8,375	$0.50 / $2.50	262.1K

116
	
101
129
	
Grok 4.1 Fast (Reasoning)
SpaceXAI · Proprietary
	
1430
±3
	57,521	$0.20 / $0.50	128K

117
	
101
130
	
Kimi K2 Thinking Turbo
Moonshot · Modified MIT
	
1430
±3
	63,353	$0.57 / $2.30	131.1K

118
	
97
148
	
amazon-nova-experimental-chat (26-02-10)
Amazon · Proprietary
	
1426
±10
	3,525	N/A	N/A

119
	
101
142
	
Mistral Medium 3.5
Mistral · Modified MIT
	
1426
±6
	11,785	$0.75 / $3.75	262.1K

120
	
105
141
	
GPT-5 Chat
OpenAI · Proprietary
	
1426
±4
	31,198	$5 / $30	N/A

121
	
101
143
	
NVIDIA-Nemotron-3-Ultra-550B-A55B (NVFP4)
Nvidia · OpenMDW-1.1
	
1426
±7
	11,545	N/A	N/A

122
	
105
141
	
Claude Opus 4 (Thinking 16K, 20250514)
Anthropic · Proprietary
	
1426
±4
	35,900	$15 / $75	200K

123
	
105
144
	
DeepSeek-V3.2-Exp (Thinking)
DeepSeek · MIT
	
1425
±7
	9,000	$0.27 / $0.41	163.8K

124
	
99
151
	
Muse Glimmer
Meta · Apache-2.0
	
1425
±10
	3,889	N/A	N/A

125
	
110
141
	
DeepSeek-V3.2
DeepSeek · MIT
	
1425
±3
	48,095	$0.28 / $0.42	163.8K

126
	
111
142
	
GLM-4.6
Z.ai · MIT
	
1424
±4
	35,814	$0.55 / $2.20	204.8K

127
	
107
148
	
Qwen3-Max (2025-09-23)
Alibaba · Proprietary
	
1423
±6
	9,027	$0.78 / $3.90	262.1K

128
	
116
143
	
DeepSeek-V3.2 (Thinking)
DeepSeek · MIT
	
1422
±4
	42,042	$0.28 / $0.42	163.8K

129
	
117
143
	
Qwen3-235B-A22B-Instruct (2507)
Alibaba · Apache 2.0
	
1422
±3
	98,119	$0.26 / $1.06	N/A

130
	
110
151
	
DeepSeek-V3.2-Exp
DeepSeek · MIT
	
1422
±6
	11,996	$0.27 / $0.41	163.8K

131
	
111
149
	
DeepSeek-R1 (0528)
DeepSeek · MIT
	
1422
±6
	18,165	$0.50 / $2.15	163.8K

132
	
115
154
	
Grok 4 Fast (Non-Reasoning)
SpaceXAI · Proprietary
	
1419
±8
	6,341	$0.20 / $0.50	N/A

133
	
117
153
	
Kimi K2 Preview (0905)
Moonshot · Modified MIT
	
1419
±7
	11,590	$0.60 / $2.50	262.1K

134
	
113
156
	
ERNIE-5.0-Preview (1022)
Baidu · Proprietary
	
1418
±9
	4,755	N/A	N/A

135
	
118
153
	
Kimi K2 Preview (0711)
Moonshot · Modified MIT
	
1418
±5
	27,142	$0.60 / $2.50	131.1K

136
	
118
154
	
DeepSeek-V3.1
DeepSeek · MIT
	
1417
±6
	14,604	$1.23 / $4.94	N/A

137
	
121
153
	
Qwen3.5-122B-A10B
Alibaba · Apache 2.0
	
1416
±4
	29,731	$0.40 / $3.20	262.1K

138
	
116
164
	
DeepSeek-V3.1-Terminus (Thinking)
DeepSeek · MIT
	
1416
±10
	3,375	$0.27 / $1	163.8K

139
	
118
157
	
DeepSeek-V3.1 (Thinking)
DeepSeek · MIT
	
1416
±7
	11,461	$1.23 / $4.94	N/A

140
	
127
154
	
MiniMax-M2.7
MiniMax · Modified MIT
	
1415
±3
	86,587	$0.30 / $1.20	204.8K

141
	
117
164
	
DeepSeek-V3.1-Terminus
DeepSeek · MIT
	
1415
±10
	3,610	$0.27 / $1	163.8K

142
	
127
153
	
Mistral Large 3
Mistral · Apache 2.0
	
1415
±3
	85,822	$0.50 / $1.50	N/A

143
	
127
153
	
Claude Haiku 4.5 (20251001)
Anthropic · Proprietary
	
1415
±2
	151,130	$1 / $5	200K

144
	
127
154
	
GPT-4.1 (2025-04-14)
OpenAI · Proprietary
	
1415
±4
	50,293	$2 / $8	1M

145
	
126
156
	
Claude Opus 4 (20250514)
Anthropic · Proprietary
	
1414
±4
	43,035	$15 / $75	200K

146
	
118
165
	
NVIDIA-Nemotron-3.5-Super-VL-120B-A12B (NVFP4)
Nvidia · OpenMDW-1.1
	
1414
±10
Preliminary
	3,987	N/A	N/A

147
	
123
160
	
Qwen3-VL-235B-A22B-Instruct
Alibaba · Apache 2.0
	
1413
±7
	11,317	$0.29 / $1.15	262.1K

148
	
118
167
	
amazon-nova-experimental-chat (26-01-10)
Amazon · Proprietary
	
1413
±10
	3,534	N/A	N/A

149
	
130
159
	
Grok 3 Preview (02-24)
SpaceXAI · Proprietary
	
1411
±4
	32,495	$3 / $15	131.1K

150
	
132
159
	
Grok 4 (0709)
SpaceXAI · Proprietary
	
1411
±4
	39,689	$1.25 / $2.50	256K

151
	
130
164
	
GLM-4.5
Z.ai · MIT
	
1411
±5
	23,800	$0.60 / $2.20	131.1K

152
	
137
159
	
Gemini 2.5 Flash
Google · Proprietary
	
1409
±2
	125,492	$0.30 / $2.50	1M

153
	
129
168
	
Hy3 preview
Tencent · tencent-hunyuan-community
	
1409
±7
	6,880	$0.29 / $1.17	262.1K

154
	
132
165
	
Qwen3.5-27B
Alibaba · Apache 2.0
	
1409
±4
	28,663	$0.27 / $2.16	262.1K

155
	
141
164
	
Mistral Medium 3.1 (2508)
Mistral · Proprietary
	
1408
±3
	95,291	$0.40 / $2	131.1K

156
	
141
169
	
Grok 4 Fast (Reasoning)
SpaceXAI · Proprietary
	
1405
±5
	18,275	$0.20 / $0.50	N/A

157
	
143
169
	
Inkling-Small
Thinky · Apache 2.0
	
1405
±5
	34,105	$0.45 / $1.20	524.3K

158
	
144
171
	
Gemini 2.5 Flash Preview (09-2025)
Google · Proprietary
	
1403
±4
	32,998	$0.30 / $2.50	1M

159
	
147
172
	
o1 (2024-12-17)
OpenAI · Proprietary
	
1402
±4
	27,807	$15 / $60	200K

160
	
148
172
	
Qwen3-235B-A22B (Non-Thinking)
Alibaba · Apache 2.0
	
1402
±5
	37,483	$0.46 / $1.82	131.1K

161
	
148
172
	
Claude Sonnet 4 (Thinking 32K, 20250514)
Anthropic · Proprietary
	
1402
±4
	34,138	$3 / $15	200K

162
	
152
172
	
GPT-5.4 nano (High)
OpenAI · Proprietary
	
1401
±4
	62,384	$0.20 / $1.25	400K

163
	
144
179
	
LongCat-Flash-Chat
Meituan · MIT
	
1401
±6
	11,169	$0.20 / $0.80	131.1K

164
	
148
180
	
Qwen3-235B-A22B-Thinking (2507)
Alibaba · Apache 2.0
	
1400
±7
	8,820	$0.45 / $3.50	128K

165
	
154
179
	
Qwen3-Next-80B-A3B-Instruct
Alibaba · Apache 2.0
	
1399
±5
	22,763	$0.09 / $1.10	262.1K

166
	
154
180
	
DeepSeek-R1
DeepSeek · MIT
	
1398
±5
	18,524	$1.35 / $5.40	N/A

167
	
158
184
	
Qwen3.5-Flash
Alibaba · Proprietary
	
1396
±4
	61,778	N/A	N/A

168
	
158
185
	
DeepSeek-V3 (0324)
DeepSeek · MIT
	
1395
±4
	44,980	$1.14 / $4.56	N/A

169
	
156
188
	
Qwen3-VL-235B-A22B-Thinking
Alibaba · Apache 2.0
	
1395
±7
	7,861	$0.40 / $4	131.1K

170
	
148
192
	
Hunyuan Vision 1.5 Thinking
Tencent · Proprietary
	
1394
±12
	2,168	N/A	N/A

171
	
159
185
	
Qwen3.5-35B-A3B
Alibaba · Apache 2.0
	
1394
±4
	30,472	$0.14 / $1	262.1K

172
	
163
187
	
Step-3.5-Flash
StepFun · Apache 2.0
	
1393
±4
	60,308	$0.10 / $0.30	262.1K

173
	
155
190
	
amazon-nova-experimental-chat (12-10)
Amazon · Proprietary
	
1393
±9
	3,731	N/A	N/A

174
	
163
188
	
MiMo-V2-Flash (Non-Thinking)
Xiaomi · MIT
	
1391
±3
	48,069	$0.10 / $0.30	262.1K

175
	
163
190
	
o4-mini (2025-04-16)
OpenAI · Proprietary
	
1391
±4
	44,847	$1.10 / $4.40	200K

176
	
163
190
	
Claude Sonnet 4 (20250514)
Anthropic · Proprietary
	
1391
±4
	39,161	$3 / $15	200K

177
	
163
190
	
MiniMax-M2.5
MiniMax · Modified MIT
	
1391
±4
	42,800	$0.27 / $0.95	204.8K

178
	
163
190
	
GPT-5 mini (High)
OpenAI · Proprietary
	
1390
±5
	26,805	$0.13 / $1	400K

179
	
165
190
	
o1-preview
OpenAI · Proprietary
	
1389
±5
	31,122	$15 / $60	N/A

180
	
167
190
	
Claude 3.7 Sonnet (Thinking 32K, 20250219)
Anthropic · Proprietary
	
1388
±4
	38,152	$3 / $15	200K

181
	
167
192
	
Solar Pro 4
Upstage · Proprietary
	
1388
±5
	23,181	$0.15 / $0.60	524.3K

182
	
167
192
	
Qwen3-Coder-480B-A35B-Instruct
Alibaba · Apache 2.0
	
1388
±5
	25,190	$0.65 / $3.25	1M

183
	
168
192
	
Mistral Medium 3 (2505)
Mistral · Proprietary
	
1387
±5
	32,783	$0.40 / $2	131.1K

184
	
163
194
	
Hunyuan T1 (20250711)
Tencent · Proprietary
	
1387
±9
	4,591	N/A	N/A

185
	
167
192
	
MiMo-V2-Flash (Thinking)
Xiaomi · MIT
	
1386
±6
	11,138	$0.10 / $0.30	262.1K

186
	
170
194
	
MiniMax-M2.1 Preview
MiniMax · MIT
	
1384
±5
	17,227	$0.30 / $1.20	204.8K

187
	
170
197
	
Hunyuan TurboS (20250416)
Tencent · Proprietary
	
1383
±6
	10,623	N/A	N/A

188
	
173
194
	
GPT-4.1 mini (2025-04-14)
OpenAI · Proprietary
	
1383
±4
	38,697	$0.40 / $1.60	1M

189
	
173
196
	
Qwen3-30B-A3B-Instruct (2507)
Alibaba · Apache 2.0
	
1382
±5
	23,315	$0.09 / $0.30	262.1K

190
	
180
198
	
Gemini 2.5 Flash-Lite Preview (Non-Thinking, 09-2025)
Google · Proprietary
	
1379
±3
	47,428	$0.10 / $0.40	1M

191
	
180
199
	
Trinity Large Preview
Apache 2.0
	
1379
±4
	31,261	$0.15 / $0.45	131K

192
	
171
207
	
GLM-4.6V
Z.ai · MIT
	
1378
±11
	2,831	$0.30 / $0.90	131.1K

193
	
185
200
	
Gemini 2.5 Flash-Lite Preview (Thinking, 06-17)
Google · Proprietary
	
1375
±5
	32,374	$0.10 / $0.40	1M

194
	
185
201
	
Qwen3-235B-A22B
Alibaba · Apache 2.0
	
1375
±5
	25,955	$0.46 / $1.82	131.1K

195
	
188
200
	
Claude 3.5 Sonnet (20241022)
Anthropic · Proprietary
	
1374
±3
	87,767	$3 / $15	200K

196
	
188
201
	
Qwen2.5-Max
Alibaba · Proprietary
	
1374
±4
	32,489	N/A	N/A

197
	
189
204
	
GLM-4.5-Air
Z.ai · MIT
	
1373
±4
	30,671	$0.13 / $0.85	131.1K

198
	
190
204
	
Claude 3.7 Sonnet (20250219)
Anthropic · Proprietary
	
1373
±4
	42,573	$3 / $15	200K

199
	
191
209
	
Qwen3-Next-80B-A3B-Thinking
Alibaba · Apache 2.0
	
1369
±6
	13,479	$0.15 / $1.20	262.1K

200
	
192
211
	
Trinity Large Thinking
Apache 2.0
	
1367
±5
	30,320	$0.25 / $0.80	262.1K

201
	
196
211
	
Gemma 3 27B IT
Google · Gemma
	
1365
±4
	46,664	$0.08 / $0.35	131.1K

202
	
194
215
	
GLM-4.7-Flash
Z.ai · MIT
	
1365
±6
	12,013	$0.06 / $0.40	200K

203
	
198
214
	
MiniMax-M1
MiniMax · Apache 2.0
	
1364
±4
	34,300	$0.55 / $2.20	1M

204
	
198
214
	
amazon-nova-experimental-chat (11-10)
Amazon · Proprietary
	
1364
±4
	26,027	N/A	N/A

205
	
196
216
	
Grok 3 Mini (High)
SpaceXAI · Proprietary
	
1364
±5
	15,594	$0.25 / $1.27	N/A

206
	
196
216
	
o3-mini (High)
OpenAI · Proprietary
	
1364
±5
	18,589	$1.10 / $4.40	200K

207
	
198
227
	
NVIDIA-Nemotron-3-Super-120B-A12B
Nvidia · NVIDIA Open Model
	
1360
±7
	7,871	N/A	N/A

208
	
199
222
	
Gemini 2.0 Flash (001)
Google · Proprietary
	
1360
±4
	43,442	$0.10 / $0.40	1M

209
	
200
225
	
DeepSeek-V3
DeepSeek · DeepSeek
	
1358
±5
	21,770	$1.14 / $4.56	N/A

210
	
200
227
	
Grok 3 Mini Beta
SpaceXAI · Proprietary
	
1358
±5
	20,932	$1.25 / $2.50	131.1K

211
	
202
232
	
Mistral Small 3.2 (2506)
Mistral · Apache 2.0
	
1356
±5
	17,459	$0.10 / $0.30	262.1K

212
	
199
235
	
INTELLECT-3
MIT
	
1356
±8
	5,434	$0.20 / $1.10	131.1K

213
	
207
234
	
Command A (03-2025)
Cohere · CC-BY-NC-4.0
	
1354
±3
	55,769	$2.50 / $10	256K

214
	
207
235
	
Gemini 2.0 Flash-Lite Preview (02-05)
Google · Proprietary
	
1354
±4
	24,955	$0.07 / $0.30	1M

215
	
205
235
	
NVIDIA-Nemotron-3.5-Lightning-30B-A3B (NVFP4)
Nvidia · OpenMDW-1.1
	
1353
±5
	21,273	N/A	N/A

216
	
202
237
	
GLM-4.5V
Z.ai · MIT
	
1352
±8
	4,821	$0.60 / $1.80	65.5K

217
	
207
235
	
gpt-oss-120b
OpenAI · Apache 2.0
	
1352
±4
	30,213	$0.15 / $0.60	131.1K

218
	
208
235
	
Gemini 1.5 Pro (002)
Google · Proprietary
	
1351
±3
	55,606	$3.50 / $10.50	2.1M

219
	
207
239
	
Step-3
StepFun · Apache 2.0
	
1349
±8
	6,292	$0.57 / $1.42	65.5K

220
	
202
248
	
Hunyuan TurboS (20250226)
Tencent · Proprietary
	
1349
±12
	2,220	N/A	N/A

221
	
211
236
	
o3-mini
OpenAI · Proprietary
	
1348
±4
	56,736	$0.55 / $2.20	200K

222
	
208
239
	
amazon-nova-experimental-chat (10-20)
Amazon · Proprietary
	
1348
±6
	11,626	N/A	N/A

223
	
204
249
	
Llama 3.1 Nemotron Ultra 253B v1
Nvidia · Nvidia Open Model
	
1348
±12
	2,549	$0.60 / $1.80	131.1K

224
	
207
247
	
Qwen3-32B
Alibaba · Apache 2.0
	
1347
±9
	3,926	$0.08 / $0.28	131.1K

225
	
213
238
	
GPT-4o (2024-05-13)
OpenAI · Proprietary
	
1346
±3
	112,881	$5 / $15	128K

226
	
207
250
	
amazon-nova-experimental-chat (10-09)
Amazon · Proprietary
	
1346
±11
	2,782	N/A	N/A

227
	
208
247
	
Qwen-Plus (0125)
Alibaba · Proprietary
	
1346
±8
	5,819	$0.40 / $1.20	131.1K

228
	
211
249
	
MiniMax-M2
MiniMax · Apache 2.0
	
1344
±8
	6,860	$0.30 / $1.20	204.8K

229
	
212
248
	
Ling-flash-2.0
Ant Group · MIT
	
1343
±7
	6,950	N/A	N/A

230
	
218
244
	
Claude 3.5 Sonnet (20240620)
Anthropic · Proprietary
	
1343
±3
	82,419	$3 / $15	200K

231
	
209
251
	
Llama 3.3 Nemotron Super 49B v1.5
Nvidia · Nvidia Open
	
1343
±10
	3,327	$0.10 / $0.40	131.1K

232
	
211
250
	
GLM-4-Plus (0111)
Z.ai · Proprietary
	
1343
±8
	5,760	N/A	N/A

233
	
209
251
	
Mercury 2
Inception AI · Proprietary
	
1342
±11
	3,188	$0.25 / $0.75	128K

234
	
211
251
	
Gemma 3 12B IT
Google · Gemma
	
1342
±10
	3,829	$0.05 / $0.15	131.1K

235
	
211
256
	
Hunyuan Turbo (0110)
Tencent · Proprietary
	
1341
±12
	2,290	N/A	N/A

236
	
212
256
	
Granite 4.2 30B
IBM · Apache 2.0
	
1340
±10
	3,403	N/A	N/A

237
	
219
254
	
GPT-5 nano (High)
OpenAI · Proprietary
	
1338
±7
	8,135	$0.03 / $0.20	400K

238
	
223
251
	
o1-mini
OpenAI · Proprietary
	
1337
±4
	51,981	$1.10 / $4.40	N/A

239
	
223
254
	
Gemini Advanced (0514)
Google · Proprietary
	
1336
±5
	50,148	N/A	N/A

240
	
224
251
	
Grok 2 (2024-08-13)
SpaceXAI · Proprietary
	
1336
±4
	63,498	$2 / $10	131.1K

241
	
224
253
	
GPT-4o (2024-08-06)
OpenAI · Proprietary
	
1336
±4
	45,499	$2.50 / $10	128K

242
	
223
254
	
QwQ-32B
Alibaba · Apache 2.0
	
1336
±4
	25,178	$0.50 / $1	16.4K

243
	
224
251
	
Llama 3.1 405B Instruct (BF16)
Meta · Llama 3.1 Community
	
1336
±4
	41,375	$4 / $4	32.8K

244
	
223
256
	
Amazon Nova 2 Lite
Amazon · Proprietary
	
1335
±6
	12,409	$0.30 / $2.50	1M

245
	
226
254
	
Llama 3.1 405B Instruct (FP8)
Meta · Llama 3.1 Community
	
1334
±4
	59,656	$4 / $4	32.8K

246
	
221
262
	
Step-2 16K Exp (202412)
StepFun · Proprietary
	
1334
±9
	4,833	N/A	N/A

247
	
230
265
	
Olmo 3.1 32B Instruct
Ai2 · Apache 2.0
	
1329
±6
	11,808	$0.20 / $0.60	65.5K

248
	
232
265
	
Yi Lightning
Proprietary
	
1328
±5
	27,332	N/A	N/A

249
	
223
276
	
Llama 3.3 Nemotron Super 49B v1
Nvidia · Nvidia
	
1328
±12
	2,218	N/A	N/A

250
	
239
266
	
Llama 4 Maverick 17B 128E Instruct
Meta · Llama 4
	
1327
±4
	39,442	$0.63 / $1.80	131.1K

251
	
238
266
	
Qwen3-30B-A3B
Alibaba · Apache 2.0
	
1327
±5
	26,156	$0.12 / $0.50	41K

252
	
228
276
	
Hunyuan Large (2025-02-10)
Tencent · Proprietary
	
1326
±10
	3,738	N/A	N/A

253
	
246
267
	
Claude 3.5 Haiku (20241022)
Anthropic · Proprietary
	
1325
±3
	69,059	$1 / $5	200K

254
	
246
270
	
GPT-4 Turbo (2024-04-09)
OpenAI · Proprietary
	
1325
±4
	98,114	$10 / $30	128K

255
	
246
270
	
Gemini 1.5 Pro (001)
Google · Proprietary
	
1324
±4
	79,138	$3.50 / $10.50	2.1M

256
	
238
276
	
DeepSeek-V2.5 (1210)
DeepSeek · DeepSeek
	
1323
±8
	6,795	N/A	N/A

257
	
243
276
	
Ring-flash-2.0
Ant Group · MIT
	
1323
±7
	6,987	N/A	N/A

258
	
243
276
	
GPT-4.1 nano (2025-04-14)
OpenAI · Proprietary
	
1322
±8
	6,103	$0.10 / $0.40	1M

259
	
246
271
	
Claude 3 Opus (20240229)
Anthropic · Proprietary
	
1322
±3
	194,909	$15 / $75	200K

260
	
220
291
	
Molmo 2 8B
Ai2 · Apache 2.0
	
1322
±21
	823	$0.20 / $0.20	36.9K

261
	
246
276
	
Llama 4 Scout 17B 16E Instruct
Meta · Llama
	
1322
±5
	29,824	$0.05 / $0.10	16.4K

262
	
246
279
	
Step-1o Turbo (202506)
StepFun · Proprietary
	
1320
±7
	8,900	N/A	N/A

263
	
247
276
	
GLM-4-Plus
Z.ai · Proprietary
	
1319
±5
	26,126	$0.44 / $1.76	204.8K

264
	
247
280
	
Qwen-Max (0919)
Alibaba · Qwen
	
1318
±6
	16,478	$1.60 / $6.40	32.8K

265
	
251
276
	
Llama 3.3 70B Instruct
Meta · Llama-3.3
	
1318
±4
	54,495	$0.10 / $0.32	131.1K

266
	
249
280
	
Gemma 3n E4B IT
Google · Gemma
	
1318
±5
	22,137	$0.06 / $0.12	32.8K

267
	
252
277
	
GPT-4o mini (2024-07-18)
OpenAI · Proprietary
	
1318
±4
	68,705	$0.15 / $0.60	128K

268
	
247
284
	
gpt-oss-20b
OpenAI · Apache 2.0
	
1318
±6
	10,417	$0.02 / $0.11	131.1K

269
	
252
285
	
Qwen2.5-Plus (1127)
Alibaba · Proprietary
	
1315
±6
	10,187	N/A	N/A

270
	
255
284
	
Mistral Large 2 (2407)
Mistral · Mistral Research
	
1314
±4
	45,459	$2 / $6	131.1K

271
	
255
285
	
Athene V2 Chat
NexusFlow
	
1314
±5
	24,739	N/A	N/A

272
	
255
285
	
NVIDIA-Nemotron-3-Nano-30B-A3B (BF16)
Nvidia · NVIDIA Open Model
	
1314
±5
	15,760	$0.06 / $0.24	262.1K

273
	
255
285
	
GPT-4 Turbo Preview (0125)
OpenAI · Proprietary
	
1313
±4
	93,439	$10 / $30	128K

274
	
255
285
	
GPT-4 Turbo Preview (1106)
OpenAI · Proprietary
	
1313
±4
	100,105	$10 / $30	128K

275
	
252
290
	
Hunyuan Standard (2025-02-10)
Tencent · Proprietary
	
1311
±10
	3,904	N/A	N/A

276
	
264
288
	
Gemini 1.5 Flash (002)
Google · Proprietary
	
1309
±4
	34,902	$0.07 / $0.30	1M

277
	
267
288
	
Grok 2 mini (2024-08-13)
SpaceXAI · Proprietary
	
1308
±4
	52,567	$2 / $10	131.1K

278
	
267
289
	
DeepSeek-V2.5
DeepSeek · DeepSeek
	
1307
±5
	24,572	N/A	N/A

279
	
267
291
	
Athene 70B (0725)
CC-BY-NC-4.0
	
1307
±6
	19,621	N/A	N/A

280
	
263
291
	
Olmo 3 32B Think
Ai2 · Apache 2.0
	
1306
±8
	5,825	$0.15 / $0.50	65.5K

281
	
269
291
	
Mistral Large (2411)
Mistral · MRL
	
1306
±4
	28,073	$2 / $6	128K

282
	
254
301
	
Mercury
Inception AI · Proprietary
	
1306
±14
	1,966	$0.25 / $0.75	128K

283
	
267
291
	
Magistral Medium (2506)
Mistral · Proprietary
	
1305
±6
	11,510	$2 / $5	40K

284
	
264
298
	
Granite 4.1 8B
IBM · Apache 2.0
	
1304
±10
	4,182	$0.05 / $0.10	131.1K

285
	
265
298
	
Gemma 3 4B IT
Google · Gemma
	
1303
±9
	4,171	$0.04 / $0.05	131.1K

286
	
274
291
	
Qwen2.5-72B-Instruct
Alibaba · Qwen
	
1303
±4
	39,406	$1.20 / $1.20	N/A

287
	
274
291
	
Mistral Small 3.1 24B Instruct (2503)
Mistral · Apache 2.0
	
1303
±5
	32,720	$0.10 / $0.30	32K

288
	
274
302
	
Llama 3.1 Nemotron 70B Instruct
Nvidia · Llama 3.1
	
1299
±8
	7,140	$1.20 / $1.20	131.1K

289
	
276
304
	
Hunyuan Large Vision
Tencent · Proprietary
	
1294
±9
	5,278	N/A	N/A

290
	
285
302
	
Llama 3.1 70B Instruct
Meta · Llama 3.1 Community
	
1293
±4
	55,240	$0.40 / $0.40	131.1K

291
	
277
311
	
Granite 4.2 3B
IBM · Apache 2.0
	
1291
±12
	3,253	N/A	N/A

292
	
285
303
	
Amazon Nova Pro 1.0
Amazon · Proprietary
	
1290
±5
	24,745	$0.80 / $3.20	300K

293
	
278
311
	
Granite 4.2 8B
IBM · Apache 2.0
	
1290
±11
	3,254	$0.06 / $0.25	131.1K

294
	
287
303
	
Gemma 2 27B IT
Google · Gemma license
	
1290
±3
	75,754	$0.65 / $0.65	8.2K

295
	
285
306
	
Jamba 1.5 Large
Jamba Open
	
1290
±7
	8,662	$2 / $8	256K

296
	
285
306
	
Reka Core (20240904)
Proprietary
	
1288
±7
	7,312	N/A	N/A

297
	
287
304
	
GPT-4 (0314)
OpenAI · Proprietary
	
1288
±5
	54,173	$30 / $60	8.2K

298
	
285
311
	
Granite-4.0-H-Small
IBM · Apache 2.0
	
1287
±8
	5,630	N/A	N/A

299
	
285
312
	
Llama 3.1 Nemotron 51B Instruct
Nvidia · Llama 3.1
	
1287
±10
	3,749	N/A	N/A

300
	
288
306
	
Gemini 1.5 Flash (001)
Google · Proprietary
	
1287
±5
	62,833	$0.07 / $0.30	1M

301
	
287
311
	
Olmo 3.1 32B Think
Ai2 · Apache 2.0
	
1286
±7
	8,300	$0.15 / $0.50	65.5K

302
	
285
312
	
Llama 3.1 Tulu 3 70B
Ai2 · Llama 3.1
	
1286
±10
	2,846	N/A	N/A

303
	
292
312
	
Claude 3 Sonnet (20240229)
Anthropic · Proprietary
	
1281
±4
	109,284	$3 / $15	200K

304
	
290
312
	
Gemma 2 9B IT SimPO
MIT
	
1280
±7
	10,072	$0.03 / $0.09	8.2K

305
	
294
313
	
Nemotron-4 340B Instruct
Nvidia · NVIDIA Open Model
	
1277
±5
	19,659	N/A	N/A

306
	
297
312
	
Llama 3 70B Instruct
Meta · Llama 3 Community
	
1277
±4
	156,876	$0.51 / $0.74	8.2K

307
	
294
315
	
Command R+ (08-2024)
Cohere · CC-BY-NC-4.0
	
1276
±7
	9,866	$0.15 / $0.60	128K

308
	
297
312
	
GPT-4 (0613)
OpenAI · Proprietary
	
1276
±4
	88,723	$30 / $60	8.2K

309
	
297
315
	
Mistral Small 24B Instruct (2501)
Mistral · Apache 2.0
	
1274
±6
	14,681	$0.05 / $0.08	32.8K

310
	
297
316
	
GLM-4 (0520)
Z.ai · Proprietary
	
1274
±7
	9,788	N/A	N/A

311
	
297
319
	
Reka Flash (20240904)
Proprietary
	
1273
±7
	7,536	N/A	N/A

312
	
301
320
	
Qwen2.5-Coder-32B-Instruct
Alibaba · Apache 2.0
	
1271
±8
	5,432	$0.87 / $0.87	32K

313
	
307
321
	
Aya Expanse 32B
Cohere · CC-BY-NC-4.0
	
1267
±5
	27,124	$0.50 / $1.50	128K

314
	
308
319
	
Gemma 2 9B IT
Google · Gemma license
	
1267
±4
	54,611	$0.03 / $0.09	8.2K

315
	
308
322
	
DeepSeek-Coder-V2
DeepSeek · DeepSeek License
	
1265
±6
	15,147	$0.14 / $0.28	128K

316
	
310
323
	
Qwen2-72B-Instruct
Alibaba · Qianwen LICENSE
	
1262
±5
	37,325	$0.90 / $0.90	32.8K

317
	
311
322
	
Command R+
Cohere · CC-BY-NC-4.0
	
1262
±4
	77,554	$3 / $15	128K

318
	
311
322
	
Claude 3 Haiku (20240307)
Anthropic · Proprietary
	
1262
±4
	117,701	$0.25 / $1.25	200K

319
	
311
323
	
Amazon Nova Lite 1.0
Amazon · Proprietary
	
1260
±5
	19,372	$0.06 / $0.24	300K

320
	
313
323
	
Gemini 1.5 Flash-8B (001)
Google · Proprietary
	
1259
±4
	35,558	$0.07 / $0.30	1M

321
	
315
323
	
Phi-4
Microsoft · MIT
	
1256
±5
	24,126	$0.07 / $0.14	16.4K

322
	
314
330
	
OLMo 2 32B Instruct (0325)
Ai2 · Apache-2.0
	
1252
±11
	3,334	$0.05 / $0.20	128K

323
	
318
329
	
Command R (08-2024)
Cohere · CC-BY-NC-4.0
	
1251
±7
	10,140	$0.15 / $0.60	128K

324
	
322
332
	
Mistral Large (2402)
Mistral · Proprietary
	
1243
±5
	62,436	$8 / $24	32K

325
	
322
332
	
Amazon Nova Micro 1.0
Amazon · Proprietary
	
1241
±5
	19,364	$0.04 / $0.14	128K

326
	
322
335
	
Jamba 1.5 Mini
Jamba Open
	
1240
±7
	8,858	$0.20 / $0.40	256K

327
	
322
339
	
Ministral 8B (2410)
Mistral · MRL
	
1238
±9
	4,781	$0.10 / $0.10	131.1K

328
	
322
339
	
Gemini Pro (Dev API)
Google · Proprietary
	
1237
±7
	18,354	$0.35 / $1.05	32.8K

329
	
324
339
	
Qwen1.5-110B-Chat
Alibaba · Qianwen LICENSE
	
1234
±6
	26,195	N/A	N/A

330
	
323
341
	
Reka Flash 21B (Online, 20240226)
Proprietary
	
1234
±7
	15,450	N/A	N/A

331
	
324
339
	
Qwen1.5-72B-Chat
Alibaba · Qianwen LICENSE
	
1234
±5
	39,302	N/A	N/A

332
	
322
342
	
Hunyuan Standard 256K
Tencent · Proprietary
	
1233
±12
	2,728	N/A	N/A

333
	
326
341
	
Mixtral 8x22B Instruct v0.1
Mistral · Apache 2.0
	
1230
±5
	51,416	$0.90 / $0.90	65.5K

334
	
327
342
	
Command R
Cohere · CC-BY-NC-4.0
	
1227
±5
	54,036	$0.15 / $0.60	128K

335
	
326
342
	
Reka Flash 21B (20240226)
Proprietary
	
1227
±6
	24,806	N/A	N/A

336
	
327
342
	
GPT-3.5 Turbo (0125)
OpenAI · Proprietary
	
1226
±5
	66,207	$0.50 / $1.50	16.4K

337
	
326
346
	
Gemini Pro
Google · Proprietary
	
1224
±12
	6,390	$0.35 / $1.05	32.8K

338
	
331
342
	
Llama 3 8B Instruct
Meta · Llama 3 Community
	
1224
±4
	104,642	$0.14 / $0.14	8.2K

339
	
327
344
	
Aya Expanse 8B
Cohere · CC-BY-NC-4.0
	
1223
±7
	9,818	N/A	N/A

340
	
331
344
	
Mistral Medium
Mistral · Proprietary
	
1223
±5
	34,550	$1.50 / $7.50	262.1K

341
	
327
347
	
Llama 3.1 Tulu 3 8B
Ai2 · Llama 3.1
	
1221
±11
	2,896	N/A	N/A

342
	
333
349
	
Zephyr ORPO 141B A35B v0.1
Apache 2.0
	
1213
±11
	4,652	N/A	N/A

343
	
338
347
	
Yi 1.5 34B Chat
Apache-2.0
	
1213
±5
	24,146	N/A	N/A

344
	
340
347
	
Llama 3.1 8B Instruct
Meta · Llama 3.1 Community
	
1211
±4
	49,605	$0.05 / $0.08	131.1K

345
	
338
353
	
Granite 3.1 8B Instruct
IBM · Apache 2.0
	
1209
±11
	3,090	N/A	N/A

346
	
340
354
	
GPT-3.5 Turbo (1106)
OpenAI · Proprietary
	
1204
±9
	16,619	$1 / $2	16.4K

347
	
341
353
	
Qwen1.5-32B-Chat
Alibaba · Qianwen LICENSE
	
1204
±6
	21,741	N/A	N/A

348
	
344
354
	
Gemma 2 2B IT
Google · Gemma license
	
1200
±4
	46,616	N/A	N/A

349
	
344
355
	
Phi-3 Medium 4K Instruct
Microsoft · MIT
	
1198
±5
	25,055	$0.17 / $0.68	N/A

350
	
345
355
	
Mixtral 8x7B Instruct v0.1
Mistral · Apache 2.0
	
1197
±4
	73,503	$0.63 / $0.63	32K

351
	
345
360
	
DBRX Instruct Preview
DBRX LICENSE
	
1196
±6
	32,191	$0.60 / $0.60	32.8K

352
	
345
364
	
Qwen1.5-14B-Chat
Alibaba · Qianwen LICENSE
	
1191
±7
	17,839	$0.30 / $0.30	N/A

353
	
345
364
	
InternLM2.5 20B Chat
Other
	
1191
±7
	9,901	$0 / $0	32.8K

354
	
347
371
	
DeepSeek LLM 67B Chat
DeepSeek · DeepSeek License
	
1185
±11
	4,932	N/A	N/A

355
	
349
370
	
WizardLM 70B
Microsoft · Llama 2 Community
	
1185
±9
	8,214	N/A	N/A

356
	
351
367
	
Yi 34B Chat
Yi License
	
1184
±7
	15,483	$0.90 / $0.90	4.1K

357
	
351
370
	
Granite 3.0 8B Instruct
IBM · Apache 2.0
	
1183
±9
	6,638	N/A	N/A

358
	
351
371
	
OpenChat 3.5
Apache-2.0
	
1183
±10
	7,968	$0.20 / $0.20	N/A

359
	
351
370
	
OpenChat 3.5 (0106)
Apache-2.0
	
1183
±8
	12,637	N/A	N/A

360
	
352
367
	
Gemma 1.1 7B IT
Google · Gemma license
	
1183
±6
	23,893	$0.03 / $0.09	8.2K

361
	
352
371
	
Snowflake Arctic Instruct
Apache 2.0
	
1180
±6
	32,832	N/A	N/A

362
	
351
371
	
Granite 3.1 2B Instruct
IBM · Apache 2.0
	
1179
±11
	3,188	N/A	N/A

363
	
352
371
	
Tulu 2 DPO 70B
AI2 ImpACT Low-risk
	
1178
±10
	6,535	N/A	N/A

364
	
352
374
	
OpenHermes 2.5 Mistral 7B
Apache-2.0
	
1176
±10
	5,006	$0.17 / $0.17	N/A

365
	
354
373
	
Vicuna 33B
Non-commercial
	
1173
±6
	22,479	$0 / $0	2K

366
	
354
375
	
Phi-3 Small 8K Instruct
Microsoft · MIT
	
1171
±6
	17,766	$0.15 / $0.60	N/A

367
	
354
377
	
Starling LM 7B Beta
Apache-2.0
	
1171
±7
	16,056	N/A	N/A

368
	
356
375
	
Llama 2 70B Chat
Meta · Llama 2 Community
	
1171
±5
	38,492	$0.70 / $2.80	4.1K

369
	
356
378
	
Starling LM 7B Alpha
CC-BY-NC-4.0
	
1168
±8
	10,224	N/A	N/A

370
	
359
378
	
Llama 3.2 3B Instruct
Meta · Llama 3.2
	
1167
±8
	7,936	$0.05 / $0.34	131.1K

371
	
356
381
	
Nous Hermes 2 Mixtral 8x7B DPO
Apache-2.0
	
1165
±12
	3,777	$0.90 / $0.90	N/A

372
	
368
384
	
Granite 3.0 2B Instruct
IBM · Apache 2.0
	
1157
±8
	6,837	N/A	N/A

373
	
364
389
	
Llama 2 70B SteerLM Chat
Nvidia · Llama 2 Community
	
1155
±13
	3,585	N/A	N/A

374
	
365
388
	
QwQ-32B-Preview
Alibaba · Apache 2.0
	
1154
±11
	3,231	$0.50 / $1	16.4K

375
	
366
391
	
SOLAR 10.7B Instruct v1.0
Upstage · CC-BY-NC-4.0
	
1153
±13
	4,155	$0.30 / $0.30	N/A

376
	
364
393
	
Dolphin 2.2.1 Mistral 7B
Apache-2.0
	
1152
±15
	1,679	$0.50 / $0.50	16.4K

377
	
369
391
	
MPT 30B Chat
CC-BY-NC-SA-4.0
	
1151
±12
	2,572	N/A	N/A

378
	
371
389
	
WizardLM 13B
Microsoft · Llama 2 Community
	
1150
±9
	7,044	$0.30 / $0.30	N/A

379
	
371
388
	
Mistral 7B Instruct v0.2
Mistral · Apache-2.0
	
1150
±7
	19,402	$0.20 / $0.20	32.8K

380
	
368
395
	
Falcon 180B Chat
Falcon-180B TII License
	
1148
±17
	1,295	N/A	N/A

381
	
371
394
	
Qwen1.5-7B-Chat
Alibaba · Qianwen LICENSE
	
1144
±10
	4,737	$0.20 / $0.20	N/A

382
	
372
393
	
Phi-3 Mini 4K Instruct (June 2024)
Microsoft · MIT
	
1143
±6
	12,297	$0.13 / $0.52	4.1K

383
	
373
393
	
Vicuna 13B
Llama 2 Community
	
1142
±7
	19,367	$0.30 / $0.30	N/A

384
	
373
393
	
Llama 2 13B Chat
Meta · Llama 2 Community
	
1142
±7
	19,174	$0.25 / $0.25	4.1K

385
	
372
396
	
Qwen-14B-Chat
Alibaba · Qianwen LICENSE
	
1139
±11
	4,964	N/A	N/A

386
	
372
395
	
PaLM 2
Google · Proprietary
	
1139
±9
	8,554	$0.50 / $0.50	25.8K

387
	
373
396
	
Gemma 7B IT
Google · Gemma license
	
1138
±9
	8,925	$0.05 / $0.08	8.2K

388
	
373
396
	
Code Llama 34B Instruct
Meta · Llama 2 Community
	
1137
±9
	7,366	$0.35 / $1.40	16.4K

389
	
377
398
	
Zephyr 7B Beta
MIT
	
1131
±9
	11,118	$0.15 / $0.15	16.4K

390
	
379
398
	
Phi-3 Mini 128K Instruct
Microsoft · MIT
	
1130
±7
	20,685	$0.13 / $0.52	N/A

391
	
383
398
	
Phi-3 Mini 4K Instruct
Microsoft · MIT
	
1128
±6
	20,118	$0.13 / $0.52	N/A

392
	
377
400
	
Guanaco 33B
Non-commercial
	
1128
±12
	2,921	N/A	N/A

393
	
375
401
	
Zephyr 7B Alpha
MIT
	
1127
±16
	1,785	N/A	N/A

394
	
384
401
	
StripedHyena Nous 7B
Apache 2.0
	
1122
±11
	5,182	$0.20 / $0.20	N/A

395
	
379
402
	
Code Llama 70B Instruct
Meta · Llama 2 Community
	
1119
±18
	1,143	$0.70 / $2.80	16.4K

396
	
389
401
	
Gemma 1.1 2B IT
Google · Gemma license
	
1117
±8
	10,854	N/A	N/A

397
	
389
401
	
Vicuna 7B
Llama 2 Community
	
1115
±9
	6,923	$0.20 / $0.20	N/A

398
	
386
403
	
SmolLM2 1.7B Instruct
Apache 2.0
	
1115
±14
	2,199	N/A	N/A

399
	
392
402
	
Llama 3.2 1B Instruct
Meta · Llama 3.2
	
1111
±8
	8,045	$0.03 / $0.20	60K

400
	
392
402
	
Mistral 7B Instruct
Mistral · Apache 2.0
	
1111
±9
	8,977	$0.07 / $0.28	4.1K

401
	
393
402
	
Llama 2 7B Chat
Meta · Llama 2 Community
	
1108
±7
	14,148	$0.15 / $0.15	4.1K

402
	
397
405
	
Gemma 2B IT
Google · Gemma license
	
1094
±11
	4,780	$0.10 / $0.10	N/A

403
	
401
405
	
Qwen1.5-4B-Chat
Alibaba · Qianwen LICENSE
	
1091
±9
	7,597	$0.10 / $0.10	N/A

404
	
402
409
	
OLMo 7B Instruct
Ai2 · Apache-2.0
	
1074
±11
	6,328	$0.20 / $0.20	N/A

405
	
404
409
	
Koala 13B
Non-commercial
	
1071
±10
	6,965	N/A	N/A

406
	
404
409
	
Alpaca 13B
Non-commercial
	
1070
±11
	5,745	N/A	N/A

407
	
402
410
	
GPT4All 13B Snoozy
Non-commercial
	
1068
±15
	1,743	N/A	N/A

408
	
404
410
	
MPT 7B Chat
CC-BY-NC-SA-4.0
	
1064
±12
	3,924	N/A	N/A

409
	
404
410
	
ChatGLM3 6B
Apache-2.0
	
1057
±12
	4,658	N/A	N/A

410
	
407
412
	
RWKV-4 Raven 14B
Apache 2.0
	
1042
±11
	4,845	N/A	N/A

411
	
410
412
	
ChatGLM2 6B
Apache-2.0
	
1025
±14
	2,658	N/A	N/A

412
	
410
412
	
OpenAssistant Pythia 12B
Apache 2.0
	
1024
±11
	6,310	N/A	N/A

413
	
413
416
	
ChatGLM 6B
Non-commercial
	
996
±12
	4,914	N/A	N/A

414
	
413
416
	
FastChat-T5 3B
Apache 2.0
	
993
±12
	4,203	N/A	N/A

415
	
413
416
	
Dolly 2.0 12B
MIT
	
983
±13
	3,412	N/A	N/A

416
	
413
417
	
LLaMA 13B
Meta · Non-commercial
	
975
±16
	2,391	$0.23 / $0.23	N/A

417
	
416
417
	
StableLM Tuned Alpha 7B
CC-BY-NC-SA-4.0
	
953
±13
	3,287	N/A	N/A
View all
Default Leaderboard Plots
Fraction of Model A Wins in A vs. B Battles (Ties Excluded)
Gemini 4 Argon (Hi...
Muse Wonder (Max)
Claude Opus 5.5 (H...
Claude Fable 5 (Hi...
Claude Opus 4.6 (H...
Claude Fable 5.1 (...
Claude Opus 4.7 (H...
Claude Opus 4.6
Gemini 3.8 Flash (...
Muse Spark 1.3 (Ma...
Claude Opus 4.7
Muse Spark 1.2 (xH...
Claude Opus 5 (Max...
Muse Spark 1.1
Claude Opus 5 (Hig...
Muse Spark
Gemini 3.7 Flash (...
Kimi K3 (Max)
Gemini 3.1 Pro Pre...
Gemini 3 Pro
Gemini 4 Argon (Hi...
Muse Wonder (Max)
Claude Opus 5.5 (H...
Claude Fable 5 (Hi...
Claude Opus 4.6 (H...
Claude Fable 5.1 (...
Claude Opus 4.7 (H...
Claude Opus 4.6
Gemini 3.8 Flash (...
Muse Spark 1.3 (Ma...
Claude Opus 4.7
Muse Spark 1.2 (xH...
Claude Opus 5 (Max...
Muse Spark 1.1
Claude Opus 5 (Hig...
Muse Spark
Gemini 3.7 Flash (...
Kimi K3 (Max)
Gemini 3.1 Pro Pre...
Gemini 3 Pro
0.00
0.47
0.56
0.71
0.69
0.55
0.61
0.58
0.58
0.67
0.64
0.58
0.58
0.53
0.00
0.70
0.53
0.69
0.00
0.00
0.42
0.44
0.59
0.45
0.00
0.46
0.54
0.59
0.00
0.45
0.41
0.51
0.49
0.00
0.57
0.55
0.58
0.00
0.53
0.57
0.51
0.42
0.55
0.60
0.55
0.53
0.55
0.71
0.65
0.51
0.40
0.53
0.00
0.54
0.58
0.56
0.00
0.44
0.56
0.49
0.49
0.40
0.48
0.51
0.51
0.43
0.52
0.37
0.47
0.57
0.48
0.00
0.49
0.56
0.55
0.00
0.29
0.41
0.58
0.51
0.33
0.55
0.54
0.51
0.43
0.54
0.51
0.45
0.55
0.49
0.59
0.58
0.49
0.54
0.51
0.31
0.55
0.45
0.60
0.67
0.50
0.39
0.52
0.50
0.57
0.44
0.58
0.57
0.50
0.00
0.49
0.51
0.58
0.00
0.45
0.00
0.40
0.52
0.45
0.50
0.47
0.36
0.56
0.52
0.60
0.43
0.60
0.46
0.48
0.51
0.55
0.54
0.00
0.39
0.54
0.45
0.49
0.46
0.61
0.53
0.50
0.47
0.52
0.49
0.39
0.53
0.52
0.57
0.37
0.53
0.53
0.55
0.42
0.46
0.47
0.49
0.49
0.48
0.64
0.50
0.48
0.52
0.59
0.49
0.56
0.48
0.00
0.50
0.59
0.51
0.00
0.42
0.41
0.45
0.57
0.57
0.50
0.44
0.53
0.52
0.40
0.60
0.49
0.57
0.46
0.00
0.58
0.52
0.47
0.00
0.33
0.00
0.29
0.48
0.46
0.43
0.48
0.48
0.48
0.60
0.57
0.43
0.52
0.49
0.45
0.49
0.51
0.51
0.00
0.36
0.55
0.35
0.63
0.49
0.56
0.40
0.51
0.41
0.40
0.43
0.45
0.57
0.36
0.00
0.52
0.52
0.58
0.00
0.42
0.59
0.49
0.53
0.55
0.42
0.57
0.61
0.51
0.51
0.57
0.55
0.58
0.50
0.00
0.53
0.56
0.59
0.00
0.42
0.49
0.60
0.43
0.45
0.43
0.40
0.47
0.44
0.43
0.48
0.43
0.42
0.43
0.00
0.49
0.52
0.46
0.00
0.47
0.51
0.47
0.52
0.51
0.50
0.54
0.48
0.52
0.54
0.51
0.64
0.50
0.57
0.00
0.51
0.52
0.56
0.00
0.00
0.00
0.00
0.00
0.41
0.00
0.52
0.43
0.00
0.00
0.55
0.00
0.00
0.00
0.00
0.00
0.00
0.53
0.00
0.30
0.43
0.46
0.51
0.42
0.51
0.49
0.63
0.50
0.42
0.51
0.48
0.47
0.51
0.49
0.00
0.57
0.51
0.00
0.47
0.45
0.42
0.44
0.51
0.49
0.45
0.47
0.41
0.48
0.49
0.48
0.44
0.48
0.48
0.00
0.43
0.48
0.00
0.31
0.42
0.44
0.45
0.46
0.42
0.46
0.47
0.49
0.53
0.49
0.42
0.41
0.54
0.44
0.47
0.49
0.52
0.63
0.00
0.00
0.00
0.00
0.49
0.00
0.00
0.45
0.00
0.00
0.00
0.00
0.00
0.00
0.00
0.00
0.00
0.00
0.38
1.00
0.50
0.00
Model B
Model A
Average Win Rate Against Each Opponent (Ties Excluded)
Battle Count for Each Pair of Models (Ties Excluded)
Confidence Intervals on Model Strength (via Bootstrapping)
USE CASES
Chat with AI
Build Apps & Websites
Write & Edit Text
Search the Web
Generate Images
Generate Videos
Chose any model
Compare Models Side by Side
LEADERBOARD RANKINGS
Overall
Agent
Alignment Index
Text
WebDev
Image-to-WebDev
Text to Image
Image Edit
Text to Video
Image to Video
Video Edit
Vision
Document
Search
COMPANY
About Us
How It Works
Blog
Careers
Leaderboard Changelog
Product Changelog
Help Center
FAQ
Report a Bug
LEGAL
Terms
Privacy
Cookies
FOLLOW
X
LinkedIn
YouTube
Discord

© Arena Intelligence 2026
